#!/usr/bin/python

import sys, time, datetime, logging
import psycopg2


# the database connection is constant through this script
db = None


def parse_line(line,op):
    
    
    if op==1:
	operation = "UPLOAD"
	split_on_comma = line.split(',')
    
        #if len(split_on_comma) <> 4:
        #    return None;
    
        # extract the date information
        date = datetime.datetime.fromtimestamp(time.mktime(time.strptime(split_on_comma[0].split('[')[0].strip())))
    
        # extract the user information
        username = split_on_comma[0].split('[')[2].split(']')[0].strip()
    
        # extract the ip address
        ip = split_on_comma[0].split('"')[1]
    
        # extract the path information
        path = split_on_comma[1].strip(' "')
    
        # extract the size of the upload
        size = "N/A"
    
        # extract the speed information
        speed = "N"

    if op==2:
	operation = "DOWNLOAD"
        split_on_comma = line.split(',')
    
        #if len(split_on_comma) <> 4:
        #    return None;
    
        # extract the date information
        date = datetime.datetime.fromtimestamp(time.mktime(time.strptime(split_on_comma[0].split('[')[0].strip())))
    
        # extract the user information
        username = split_on_comma[0].split('[')[2].split(']')[0].strip()
    
        # extract the ip address
        ip = split_on_comma[0].split('"')[1]
    
        # extract the path information
        path = split_on_comma[1].strip(' "')
    
        # extract the size of the upload
        size = "N/A"
    
        # extract the speed information
        speed = "NA"

    if op==3:
	operation = "MKDIR"
	split_on_comma = line.split(',')
    
        #if len(split_on_comma) <> 4:
        #    return None;
    
        # extract the date information
        date = datetime.datetime.fromtimestamp(time.mktime(time.strptime(split_on_comma[0].split('[')[0].strip())))
    
        # extract the user information
        username = split_on_comma[0].split('[')[2].split(']')[0].strip()
    
        # extract the ip address
        ip = split_on_comma[0].split('"')[1]
    
        # extract the path information
        path = split_on_comma[1].strip(' "')
    
        # extract the size of the upload
        size = "N/A"
    
        # extract the speed information
        speed = "N/A"

    if op==4:
	operation = "RMDIR"
	split_on_comma = line.split(',')
    
        #if len(split_on_comma) <> 4:
        #    return None;
    
        # extract the date information
        date = datetime.datetime.fromtimestamp(time.mktime(time.strptime(split_on_comma[0].split('[')[0].strip())))
    
        # extract the user information
        username = split_on_comma[0].split('[')[2].split(']')[0].strip()
    
        # extract the ip address
        ip = split_on_comma[0].split('"')[1]
    
        # extract the path information
        path = split_on_comma[1].strip(' "')
    
        # extract the size of the upload
        size = "N/A"
    
        # extract the speed information
        speed = "N/A"

    if op==5:
	operation = "DELETE"
	split_on_comma = line.split(',')
    
        #if len(split_on_comma) <> 4:
        #    return None;
    
        # extract the date information
        date = datetime.datetime.fromtimestamp(time.mktime(time.strptime(split_on_comma[0].split('[')[0].strip())))
    
        # extract the user information
        username = split_on_comma[0].split('[')[2].split(']')[0].strip()
    
        # extract the ip address
        ip = split_on_comma[0].split('"')[1]
    
        # extract the path information
        path = split_on_comma[1].strip(' "')
    
        # extract the size of the upload
        size = "N/A"
    
        # extract the speed information
        speed = "N/A"

    if op==6:
	operation = "RENAME"
	split_on_comma = line.split(',')
    
        #if len(split_on_comma) <> 4:
        #    return None;
    
        # extract the date information
        date = datetime.datetime.fromtimestamp(time.mktime(time.strptime(split_on_comma[0].split('[')[0].strip())))
    
        # extract the user information
        username = split_on_comma[0].split('[')[2].split(']')[0].strip()
    
        # extract the ip address
        ip = split_on_comma[0].split('"')[1]
    
        # extract the path information
        path = split_on_comma[1].strip(' "')
    
        # extract the size of the upload
        size = "N/A"
    
        # extract the speed information
        speed = "N/A"

    if op==7:
	operation = "LOGIN"
	split_on_comma = line
    
        #if len(split_on_comma) <> 4:
        #    return None;
    
        # extract the date information
        date = datetime.datetime.fromtimestamp(time.mktime(time.strptime(split_on_comma.split('[')[0].strip())))
    
        # extract the user information
        username = split_on_comma.split('[')[2].split(']')[0].strip()
    
        # extract the ip address
        ip = split_on_comma.split('"')[1]
    
        # extract the path information
        path = "N/A"
    
        # extract the size of the upload
        size = "N/A"
    
        # extract the speed information
        speed = "N/A"


    return { 'date': date, 'username': username, 'ip': ip, 'path': path, 'size': size, 'speed': speed, 'operation': operation }


def save_entry(details):
    
    logging.info('[%s] Writing log entry for %s, uploaded on %s' % (datetime.datetime.now(), details['path'], details['date']))
    
    # database cursor
    cursor = db.cursor()
    
    # write the data to the database
    cursor.execute('INSERT INTO vsftplogs (date, username, ip, path, size, speed,operation) VALUES (%(date)s, %(username)s, %(ip)s, %(path)s, %(size)s, %(speed)s, %(operation)s);', details)
    
    # commit changes
    db.commit()
    
    # close the cursor
    cursor.close()


def scan_file(path):
    
    # get the offset so we can skip all older items
    offset = get_offset()

    # iterate over each line in the log file
    for line in open(path, 'r'):
        
        # check to see if this line might be a file upload entry
        if "ok upload:" in line.lower():
            # OP = 1
            # extract details from the raw log file line
            details = parse_line(line,1)
            
            if details is None:
                continue
           
            # go to the next log entry if this one is older than the offset
            if offset is not None and details['date'] <= offset[0]:
                continue

            # save the log entry to the database
            save_entry(details)

	if "ok download:" in line.lower():
            # OP = 2
            # extract details from the raw log file line
            details = parse_line(line,2)
            
            if details is None:
                continue
           
            # go to the next log entry if this one is older than the offset
            if offset is not None and details['date'] <= offset[0]:
                continue

            # save the log entry to the database
            save_entry(details)

	if "ok mkdir:" in line.lower():
            # OP = 3
            # extract details from the raw log file line
            details = parse_line(line,3)
            
            if details is None:
                continue
           
            # go to the next log entry if this one is older than the offset
            if offset is not None and details['date'] <= offset[0]:
                continue

            # save the log entry to the database
            save_entry(details)

	if "ok rmdir:" in line.lower():
            # OP = 4
            # extract details from the raw log file line
            details = parse_line(line,4)
            
            if details is None:
                continue
           
            # go to the next log entry if this one is older than the offset
            if offset is not None and details['date'] <= offset[0]:
                continue

            # save the log entry to the database
            save_entry(details)

	if "ok delete:" in line.lower():
            # OP = 5
            # extract details from the raw log file line
            details = parse_line(line,5)
            
            if details is None:
                continue
           
            # go to the next log entry if this one is older than the offset
            if offset is not None and details['date'] <= offset[0]:
                continue

            # save the log entry to the database
            save_entry(details)

	if "ok rename:" in line.lower():
            # OP = 6
            # extract details from the raw log file line
            details = parse_line(line,6)
            
            if details is None:
                continue
           
            # go to the next log entry if this one is older than the offset
            if offset is not None and details['date'] <= offset[0]:
                continue

            # save the log entry to the database
            save_entry(details)

	if "ok login:" in line.lower():
            # OP = 6
            # extract details from the raw log file line
            details = parse_line(line,7)
            
            if details is None:
                continue
           
            # go to the next log entry if this one is older than the offset
            if offset is not None and details['date'] <= offset[0]:
                continue

            # save the log entry to the database
            save_entry(details)

def get_offset():
    
    cursor = db.cursor()
    
    # get the newest log entry so that we can compare against it
    cursor.execute('SELECT date FROM vsftplogs ORDER BY id DESC LIMIT 1')
    
    # read it in from the cursor
    offset = cursor.fetchone()
    
    cursor.close()
    
    # provide the query result
    return offset


if __name__ == '__main__':

    if len(sys.argv) <> 3:
        
        sys.exit('modo de uso: python parser.py <cadena de conexion> <archivo log>')
    
    # initialize the logger
    logging.basicConfig(filename='/var/log/vsftpd-upload-parser.log', level=logging.DEBUG)
    
    # connect to the database
    db = psycopg2.connect(sys.argv[1])
    
    # begin the file scan
    scan_file(sys.argv[2])
    
    # close the database connection
db.close()
