#!/usr/bin/python

import sys, time, datetime, logging
import psycopg2


# the database connection is constant through this script
db = None


if __name__ == '__main__':

    if len(sys.argv) <> 4:
        
        sys.exit('modo de uso: python search.py <cadena de conexion> <opc> <val>')
    
    
    # connect to the database
    db = psycopg2.connect(sys.argv[1])
    
    #opcion
    opc=sys.argv[2]
    
    valor=sys.argv[3]

    cursor = db.cursor()
try:    
    # get the newest log entry so that we can compare against it
    if opc == "-U":
    	cursor.execute("SELECT * FROM vsftplogs WHERE username='%s' ORDER BY id ASC" %valor)

    if  opc == "-F":
        valor = "%" + valor + "%"
        cursor.execute("SELECT * FROM vsftplogs WHERE path LIKE '%s' ORDER BY id ASC" %valor)

    if opc == "-D":
        #valor = "%" + valor + "%"
        cursor.execute("SELECT * FROM vsftplogs WHERE date_trunc('day',date) = '%s' ORDER BY date ASC" %valor)

    if opc == "-O":
        cursor.execute("SELECT * FROM vsftplogs WHERE operation = '%s' ORDER BY date ASC" %valor)

    # read it in from the cursor
    offset = cursor.fetchall()
    
    cursor.close()
    
    print "se encontraron los sigueintes resultados para el valor: " + valor
    #falta ponerle la hora por ejemplo
    for row in offset:
	print "fecha -> " + row[1].strftime('%Y/%m/%d') + "  ip -> " + row[3] + "  directorio/archivo -> " + row[4] + "  operacion  -> " + row[7]

    

except psycopg2.DatabaseError, e:

    print 'Error %s' % e
    sys.exit(1)
finally:
    # close the database connection
    db.close()
